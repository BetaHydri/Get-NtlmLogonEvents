﻿<#
    .SYNOPSIS
    Gets an abbreviated set of info about NTLMv1 only or NTMLv1 and NTLMv2 logon events.
			
    .DESCRIPTION
    This script queries the Windows Security eventlog for NTLMv1 only or NTLM v1, NTLMv2 and LM logons in eventid 4624. The number of events returned is configurable. Whether null session logon events are included is configurable. It can be run against all domain controllers, a remote member server, or the localhost. If used against anything other than the localhost, WinRM is required to be listening on those remote hosts. If used against DCs, the ActiveDirectory PS module is required. 

    .EXAMPLE
    Get-NtlmLogonEvents
			
    Gets the last 30 NTLMv1 logon events from the localhost.

    .EXAMPLE
    Get-NtlmLogonEvents -NumEvents 10

    Gets the last 10 NTLMv1 logon events from the localhost.

    .EXAMPLE
    Get-NtlmLogonEvents -Target server.contoso.com

    Gets the last 30 NTLMv1 logon events from server.contoso.com via WinRM.
	
    .EXAMPLE
    Get-NtlmLogonEvents -Target server.contoso.com -OnlyNTLMv1 $false

    Gets the last 30 NTLMv1, NTLMv2 and LM logon events from server.contoso.com via WinRM.

    .EXAMPLE
    Get-NtlmLogonEvents -Target DCs -OnlyNTLMv1 $false

    Gets the last 30 NTLMv1, NTLMv2 or LM logon events on each domain controller in the domain of the localhost. Leverages WinRM and ActiveDirectory PS module.

    .EXAMPLE
    Get-NtlmLogonEvents -NullSession $false

    Gets the last 30 NTLMv1 logon events--excluding null session logons--from the localhost.
			
    .PARAMETER NumEvents
    An optional parameter that overrides the default value of 30. Enter a string indicating the desired number of events to return (per host).
				
    .PARAMETER Target
    An optional parameter that specifies the target computer(s). By default, the localhost is targeted. Valid values are "DCs" or any fully qualified DNS hostname that resolves. If you use this parameter, the remote computer must be able to accept WS-Man requests. You may need to do a "winrm quickconfig" on that remote computer to enable this.

    .PARAMETER NullSession
    An optional parameter that enables you to filter out all null session NTLM logons (without ANONYMOUS LOGONs). By default, all NTLM logons including null sessions are included. If you'd like to filter out null sessions, use this parameter. This parameter can make it much easier to find identifiable users to contact.
			
    .LINK
    TechNet The Most Misunderstood Windows Security Setting of All Time
    http://technet.microsoft.com/en-us/magazine/2006.08.securitywatch.aspx

    .LINK
    Microsoft Windows 10 and Windows Server 2016 security auditing and monitoring reference
    https://www.microsoft.com/en-us/download/details.aspx?id=52630
#>

[cmdletbinding()]
param([Int64]$NumEvents = 30,
  [boolean]$NullSession = $true,
  [boolean]$OnlyNTLMv1 = $true,
  [string]$Target = "."
)
$error.Clear()
if ($OnlyNTLMv1) {

  if ($NullSession) {
    # This finds NTLM V1 logon events
    $NtLmFilter = "Event[System[(EventID=4624)]]and Event[EventData[Data[@Name='LmPackageName']='NTLM V1']]"
  }
  else {
    # This finds NTLM V1 logon events without null session logons
    $NtLmFilter = "Event[System[(EventID=4624)]]and Event[EventData[Data[@Name='LmPackageName']='NTLM V1']] and Event[EventData[Data[@Name='TargetUserName']!='ANONYMOUS LOGON']]"
  }
} 
elseif (-not $OnlyNTLMv1) {
  if ($NullSession) {
    # This finds NTLM logon events
    $NtlmFilter = "Event[System[(EventID=4624)]]and Event[EventData[Data[@Name='LmPackageName']!='-']]"
  }
  else {
    # This finds NTLM logon events without null session logons
    $NtLmFilter = "Event[System[(EventID=4624)]]and Event[EventData[Data[@Name='LmPackageName']!='-']] and Event[EventData[Data[@Name='TargetUserName']!='ANONYMOUS LOGON']]"
  }


}

if ($Target -eq "."){
  if ($OnlyNTLMv1) {
    Write-Host "Querying security log for NTLM v1 events (ID 4624) on $env:COMPUTERNAME"
  } 
  else {
    Write-Host "Querying security log for NTLM v1 and NTLM v2 events (ID 4624) $Target" 
  }

  try {
    Get-WinEvent -Logname security -MaxEvents $NumEvents -FilterXPath $NtlmFilter -ErrorAction Stop |
    Select-Object @{Label='Time';Expression={$_.TimeCreated.ToString('g')}},
    @{Label='UserName';Expression={$_.Properties[5].Value}},
    @{Label='WorkstationName';Expression={$_.Properties[11].Value}},
    @{Label='IPAdress';Expression={$_.Properties[18].Value}},
    @{Label='TCPPort';Expression={$_.Properties[19].Value}},
    @{Label="LogonType";Expression={$_.properties[8].value}},
    @{Label="ImpersonationLevel";Expression={$_.properties[20].value}},
    @{Label="LMPackageName";Expression={$_.properties[14].value}},
    @{Label="TargetDomainName";Expression={$_.properties[6].value}},
    @{Label="ProcessName";Expression={$_.properties[17].value}}
  }
  Catch{
    Write-Host "$error"
  } 
}
else {
  #using winRM
  $remoteScript = {
      Get-WinEvent -Logname security -MaxEvents $Using:NumEvents -FilterXPath $Using:NtlmFilter -ErrorAction Stop |
      Select-Object @{Label='Time';Expression={$_.TimeCreated.ToString('g')}},
          @{Label='UserName';Expression={$_.Properties[5].Value}},
          @{Label='WorkstationName';Expression={$_.Properties[11].Value}},
          @{Label='IPAdress';Expression={$_.Properties[18].Value}},
          @{Label='TCPPort';Expression={$_.Properties[19].Value}},
          @{Label="LogonType";Expression={$_.properties[8].value}},
          @{Label="ImpersonationLevel";Expression={$_.properties[20].value}},
          @{Label="LMPackageName";Expression={$_.properties[14].value}},
          @{Label="TargetDomainName";Expression={$_.properties[6].value}},
          @{Label="ProcessName";Expression={$_.properties[17].value}}
  }
  if ($Target -eq "DCs"){
    Import-Module ActiveDirectory
    $dcs = Get-ADDomainController -Filter * | Select-Object -expand hostname
    if ($OnlyNTLMv1) {
      Write-Host "Querying security log for NTLM v1 events (ID 4624)  on DCs $dcs"
    } 
    else {
      Write-Host "Querying security log for NTLM v1 and NTLM v2 events (ID 4624)  on DCs $dcs" 
    }

    try {
      Invoke-Command -ComputerName $dcs -ScriptBlock $remoteScript | Select-Object -Property Time,UserName,WorkstationName,LogonType,ImpersonationLevel,PSComputerName,LMPackageName,TargetDomainName,ProcessName -ErrorAction Stop
    }
    Catch{
      Write-Host "Domain Controller: $dcs`n Error: $error"
    }
  }
  else {
    if ($OnlyNTLMv1) {
      Write-Host "Querying security log for NTLM v1 events (ID 4624) on remote host: $Target"
    } 
    else {
      Write-Host "Querying security log for NTLM v1 and NTLM v2 events (ID 4624)  on remote host: $Target" 
    }    

    try {
      Invoke-Command -ComputerName $Target -ScriptBlock $remoteScript | Select-Object -Property Time,UserName,WorkstationName,LogonType,ImpersonationLevel,PSComputerName,LMPackageName,TargetDomainName,ProcessName -ErrorAction Stop
    }
    catch {
      Write-Host "Server: $Target Error: $error"
    }
  }
}

#########################Various info bits to help others modify this script to meet other needs######################################################
#
# Properties (EventData) fields of event 4624:
# Index Property                  Sample Value
# ----- ------------------------- -------------------------------------
# [0]   SubjectUserSid            S-1-0-0
# [1]   SubjectUserName           -
# [2]   SubjectDomainName         -
# [3]   SubjectLogonId            0x0
# [4]   TargetUserSid             S-1-5-7
# [5]   TargetUserName            ANONYMOUS LOGON
# [6]   TargetDomainName          NT AUTHORITY
# [7]   TargetLogonId             0x12cff454c
# [8]   LogonType                 3
# [9]   LogonProcessName          NtLmSsp
# [10]  AuthenticationPackageName NTLM
# [11]  WorkstationName           UAA-HONLAB01
# [12]  LogonGuid                 {00000000-0000-0000-0000-000000000000}
# [13]  TransmittedServices       -
# [14]  LmPackageName             NTLM V1
# [15]  KeyLength                 128
# [16]  ProcessId                 0x0
# [17]  ProcessName               -
# [18]  IpAddress                 128.208.99.146
# [19]  IpPort                    58560
# [20]  ImpersonationLevel        %%1833
# ImpersonationLevel is a replacement string with these mappings:
# 1833 = Impersonation

# Event log query with a time limit
#<QueryList>
#  <Query Id="0" Path="Security         
#    <Select Path="Security">*[System[(EventID=4624) and TimeCreated[@SystemTime&gt;='2014-03-07T23:33:13.000Z']]]</Select>
#  </Query>
#</QueryList>

# Filter for 4624 (Logon) events
# $loginEventFilter = "*[System[(EventID=4624)]]"
# $equallyValidFilter = "Event[System[(EventID=4624)]]"

# This finds all NTLM events, V1 and V2
# $NtlmFilter = "Event[System[(EventID=4624)]]and Event[EventData[Data[@Name='LmPackageName']!='-']]"

# Event Viewer query for NTLM events
#<QueryList>
#  <Query Id="0" Path="Security         
#    <Select Path="Security">Event[System[(EventID=4624)]] and Event[EventData[Data[@Name='LmPackageName']!='-']]</Select>
#  </Query>
#</QueryList>
#

<#You'll see such anonymous logons also referred to as null sessions. To create a null session, try this:
  C:\>net use \\PC01\ipc$ "" /user:""
  The command completed successfully.
That will trigger a security event exactly like the one you posted above. But I haven't exactly hacked your machine at this point... so it isn't much to worry about per se. 
There isn't much you can do with a null session. And you can further restrict it with GPOs/Local Security Policy:
1. Network access: Allow anonymous SID/Name translation 
2. Network access: Do not allow anonymous enumeration of SAM accounts 
3. Network access: Do not allow anonymous enumeration of SAM accounts and shares 
4. Network access: Let Everyone permissions apply to anonymous users 
5. Network access: Named Pipes that can be accessed anonymously 
6. Network access: Shares that can be accessed anonymously 
#>
# SIG # Begin signature block
# MIIgUgYJKoZIhvcNAQcCoIIgQzCCID8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDm5MU4WXMTYde8
# /jglhzE+jS0XExtHcOuqW+pOhVmX06CCG1wwggO3MIICn6ADAgECAhAM5+DlF9hG
# /o/lYPwb8DA5MA0GCSqGSIb3DQEBBQUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0wNjExMTAwMDAwMDBa
# Fw0zMTExMTAwMDAwMDBaMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lD
# ZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAK0OFc7kQ4BcsYfzt2D5cRKlrtwmlIiq9M71IDkoWGAM+IDaqRWVMmE8
# tbEohIqK3J8KDIMXeo+QrIrneVNcMYQq9g+YMjZ2zN7dPKii72r7IfJSYd+fINcf
# 4rHZ/hhk0hJbX/lYGDW8R82hNvlrf9SwOD7BG8OMM9nYLxj+KA+zp4PWw25EwGE1
# lhb+WZyLdm3X8aJLDSv/C3LanmDQjpA1xnhVhyChz+VtCshJfDGYM2wi6YfQMlqi
# uhOCEe05F52ZOnKh5vqk2dUXMXWuhX0irj8BRob2KHnIsdrkVxfEfhwOsLSSplaz
# vbKX7aqn8LfFqD+VFtD/oZbrCF8Yd08CAwEAAaNjMGEwDgYDVR0PAQH/BAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFEXroq/0ksuCMS1Ri6enIZ3zbcgP
# MB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMA0GCSqGSIb3DQEBBQUA
# A4IBAQCiDrzf4u3w43JzemSUv/dyZtgy5EJ1Yq6H6/LV2d5Ws5/MzhQouQ2XYFwS
# TFjk0z2DSUVYlzVpGqhH6lbGeasS2GeBhN9/CTyU5rgmLCC9PbMoifdf/yLil4Qf
# 6WXvh+DfwWdJs13rsgkq6ybteL59PyvztyY1bV+JAbZJW58BBZurPSXBzLZ/wvFv
# hsb6ZGjrgS2U60K3+owe3WLxvlBnt2y98/Efaww2BxZ/N3ypW2168RJGYIPXJwS+
# S86XvsNnKmgR34DnDDNmvxMNFG7zfx9jEB76jRslbWyPpbdhAbHSoyahEHGdreLD
# +cOZUbcrBwjOLuZQsqf6CkUvovDyMIIFKjCCBBKgAwIBAgIQB9/Iv/w6ZPQnfzfB
# pAIbfDANBgkqhkiG9w0BAQsFADByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhE
# aWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMB4XDTE4MDUw
# ODAwMDAwMFoXDTE5MDUxMzEyMDAwMFowZzELMAkGA1UEBhMCREUxEDAOBgNVBAgT
# B0JhdmFyaWExFjAUBgNVBAcTDVVudGVyZm9laHJpbmcxFjAUBgNVBAoTDUphbiBU
# aWVkZW1hbm4xFjAUBgNVBAMTDUphbiBUaWVkZW1hbm4wggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQC+mPOdCge8upjIb3qv9WdjvTxbPbjJIVMKSMwm5kS/
# dfeaM1eIM75xR/2A7hdZCwKMf75MWW6UMc6fawzeLL1wHjVfX36RmdEhiJhSu0wh
# MLpi5BOYNAKESPLeibFegvAdEXpqD4mSLNj2As5kDavt4nGJsjd2thzC7DAio8xA
# CT7+S1jaPIXSv49MC/FUaRHdYc8jVBo9RshtZ0Gn1sYyqdNFjbzR5qQ/MZABa64u
# JaScG/0D2TZmpszw0d1u4sw3Ls/ghy1welyibKpB+bXui5s9ANTV79dX8nNLWR3+
# xyXSEBK2d7xDCWzALV/CgzZc38tQzZYuX+tu6gTafOC9AgMBAAGjggHFMIIBwTAf
# BgNVHSMEGDAWgBRaxLl7KgqjpepxA8Bg+S32ZXUOWDAdBgNVHQ4EFgQUoJiGFUrE
# s5t2dJOxnZfA967G5ZcwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUF
# BwMDMHcGA1UdHwRwMG4wNaAzoDGGL2h0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9z
# aGEyLWFzc3VyZWQtY3MtZzEuY3JsMDWgM6Axhi9odHRwOi8vY3JsNC5kaWdpY2Vy
# dC5jb20vc2hhMi1hc3N1cmVkLWNzLWcxLmNybDBMBgNVHSAERTBDMDcGCWCGSAGG
# /WwDATAqMCgGCCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BT
# MAgGBmeBDAEEATCBhAYIKwYBBQUHAQEEeDB2MCQGCCsGAQUFBzABhhhodHRwOi8v
# b2NzcC5kaWdpY2VydC5jb20wTgYIKwYBBQUHMAKGQmh0dHA6Ly9jYWNlcnRzLmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydFNIQTJBc3N1cmVkSURDb2RlU2lnbmluZ0NBLmNy
# dDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4IBAQCpibtFWOEBxojIdqYw
# Kp3r4TmV5egcP5lulykzpg0F8fPQUC1+dNSroKdOzwP1B1krOwgeoyAMOMVc2Sxo
# 5ZKTkcZbANfxNgD4MNbyWXPmfp1W4a8rY8cD9S0pxTTTZb0OtKQRqNuRlTV65QEe
# k0OcMFXNgRoYmfjfrNyvpMsfomXCJVO1hcbkXDRx9cUl/sAndZme6P8aWvjC44Ev
# T/As32bygnOYGusx7W9Fyvo0IYAXbhKL8o9dITxXi/dbrFXcR/D5YXKUhxxxVkVU
# wNNYClSWICifrbvEYuafp+V8cC74s9seIXXq2+JKMKXsm0cUrjd8nnu6HmvR5vvO
# FgylMIIFMDCCBBigAwIBAgIQBAkYG1/Vu2Z1U0O1b5VQCDANBgkqhkiG9w0BAQsF
# ADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQL
# ExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElE
# IFJvb3QgQ0EwHhcNMTMxMDIyMTIwMDAwWhcNMjgxMDIyMTIwMDAwWjByMQswCQYD
# VQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGln
# aWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29k
# ZSBTaWduaW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+NOz
# HH8OEa9ndwfTCzFJGc/Q+0WZsTrbRPV/5aid2zLXcep2nQUut4/6kkPApfmJ1DcZ
# 17aq8JyGpdglrA55KDp+6dFn08b7KSfH03sjlOSRI5aQd4L5oYQjZhJUM1B0sSgm
# uyRpwsJS8hRniolF1C2ho+mILCCVrhxKhwjfDPXiTWAYvqrEsq5wMWYzcT6scKKr
# zn/pfMuSoeU7MRzP6vIK5Fe7SrXpdOYr/mzLfnQ5Ng2Q7+S1TqSp6moKq4TzrGdO
# tcT3jNEgJSPrCGQ+UpbB8g8S9MWOD8Gi6CxR93O8vYWxYoNzQYIH5DiLanMg0A9k
# czyen6Yzqf0Z3yWT0QIDAQABo4IBzTCCAckwEgYDVR0TAQH/BAgwBgEB/wIBADAO
# BgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwMweQYIKwYBBQUHAQEE
# bTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYB
# BQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3Vy
# ZWRJRFJvb3RDQS5jcnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmw0LmRp
# Z2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0
# dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cmwwTwYDVR0gBEgwRjA4BgpghkgBhv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBz
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCgYIYIZIAYb9bAMwHQYDVR0OBBYEFFrE
# uXsqCqOl6nEDwGD5LfZldQ5YMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3z
# bcgPMA0GCSqGSIb3DQEBCwUAA4IBAQA+7A1aJLPzItEVyCx8JSl2qB1dHC06GsTv
# MGHXfgtg/cM9D8Svi/3vKt8gVTew4fbRknUPUbRupY5a4l4kgU4QpO4/cY5jDhNL
# rddfRHnzNhQGivecRk5c/5CxGwcOkRX7uq+1UcKNJK4kxscnKqEpKBo6cSgCPC6R
# o8AlEeKcFEehemhor5unXCBc2XGxDI+7qPjFEmifz0DLQESlE/DmZAwlCEIysjaK
# JAL+L3J+HNdJRZboWR3p+nRka7LrZkPas7CM1ekN3fYBIM6ZMWM9CBoYs4GbT8aT
# EAb8B4H6i9r5gkn3Ym6hU/oSlBiFLpKR6mhsRDKyZqHnGKSaZFHvMIIGajCCBVKg
# AwIBAgIQAwGaAjr/WLFr1tXq5hfwZjANBgkqhkiG9w0BAQUFADBiMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBBc3N1cmVkIElEIENBLTEwHhcNMTQx
# MDIyMDAwMDAwWhcNMjQxMDIyMDAwMDAwWjBHMQswCQYDVQQGEwJVUzERMA8GA1UE
# ChMIRGlnaUNlcnQxJTAjBgNVBAMTHERpZ2lDZXJ0IFRpbWVzdGFtcCBSZXNwb25k
# ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCjZF38fLPggjXg4PbG
# KuZJdTvMbuBTqZ8fZFnmfGt/a4ydVfiS457VWmNbAklQ2YPOb2bu3cuF6V+l+dSH
# dIhEOxnJ5fWRn8YUOawk6qhLLJGJzF4o9GS2ULf1ErNzlgpno75hn67z/RJ4dQ6m
# WxT9RSOOhkRVfRiGBYxVh3lIRvfKDo2n3k5f4qi2LVkCYYhhchhoubh87ubnNC8x
# d4EwH7s2AY3vJ+P3mvBMMWSN4+v6GYeofs/sjAw2W3rBerh4x8kGLkYQyI3oBGDb
# vHN0+k7Y/qpA8bLOcEaD6dpAoVk62RUJV5lWMJPzyWHM0AjMa+xiQpGsAsDvpPCJ
# EY93AgMBAAGjggM1MIIDMTAOBgNVHQ8BAf8EBAMCB4AwDAYDVR0TAQH/BAIwADAW
# BgNVHSUBAf8EDDAKBggrBgEFBQcDCDCCAb8GA1UdIASCAbYwggGyMIIBoQYJYIZI
# AYb9bAcBMIIBkjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29t
# L0NQUzCCAWQGCCsGAQUFBwICMIIBVh6CAVIAQQBuAHkAIAB1AHMAZQAgAG8AZgAg
# AHQAaABpAHMAIABDAGUAcgB0AGkAZgBpAGMAYQB0AGUAIABjAG8AbgBzAHQAaQB0
# AHUAdABlAHMAIABhAGMAYwBlAHAAdABhAG4AYwBlACAAbwBmACAAdABoAGUAIABE
# AGkAZwBpAEMAZQByAHQAIABDAFAALwBDAFAAUwAgAGEAbgBkACAAdABoAGUAIABS
# AGUAbAB5AGkAbgBnACAAUABhAHIAdAB5ACAAQQBnAHIAZQBlAG0AZQBuAHQAIAB3
# AGgAaQBjAGgAIABsAGkAbQBpAHQAIABsAGkAYQBiAGkAbABpAHQAeQAgAGEAbgBk
# ACAAYQByAGUAIABpAG4AYwBvAHIAcABvAHIAYQB0AGUAZAAgAGgAZQByAGUAaQBu
# ACAAYgB5ACAAcgBlAGYAZQByAGUAbgBjAGUALjALBglghkgBhv1sAxUwHwYDVR0j
# BBgwFoAUFQASKxOYspkH7R7for5XDStnAs0wHQYDVR0OBBYEFGFaTSS2STKdSip5
# GoNL9B6Jwcp9MH0GA1UdHwR2MHQwOKA2oDSGMmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydEFzc3VyZWRJRENBLTEuY3JsMDigNqA0hjJodHRwOi8vY3Js
# NC5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNybDB3BggrBgEF
# BQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBB
# BggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# QXNzdXJlZElEQ0EtMS5jcnQwDQYJKoZIhvcNAQEFBQADggEBAJ0lfhszTbImgVyb
# hs4jIA+Ah+WI//+x1GosMe06FxlxF82pG7xaFjkAneNshORaQPveBgGMN/qbsZ0k
# fv4gpFetW7easGAm6mlXIV00Lx9xsIOUGQVrNZAQoHuXx/Y/5+IRQaa9YtnwJz04
# HShvOlIJ8OxwYtNiS7Dgc6aSwNOOMdgv420XEwbu5AO2FKvzj0OncZ0h3RTKFV2S
# Qdr5D4HRmXQNJsQOfxu19aDxxncGKBXp2JPlVRbwuwqrHNtcSCdmyKOLChzlldqu
# xC5ZoGHd2vNtomHpigtt7BIYvfdVVEADkitrwlHCCkivsNRu4PQUCjob4489yq9q
# jXvc2EQwggbNMIIFtaADAgECAhAG/fkDlgOt6gAK6z8nu7obMA0GCSqGSIb3DQEB
# BQUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNV
# BAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQg
# SUQgUm9vdCBDQTAeFw0wNjExMTAwMDAwMDBaFw0yMTExMTAwMDAwMDBaMGIxCzAJ
# BgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5k
# aWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3VyZWQgSUQgQ0EtMTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOiCLZn5ysJClaWAc0Bw0p5W
# VFypxNJBBo/JM/xNRZFcgZ/tLJz4FlnfnrUkFcKYubR3SdyJxArar8tea+2tsHEx
# 6886QAxGTZPsi3o2CAOrDDT+GEmC/sfHMUiAfB6iD5IOUMnGh+s2P9gww/+m9/ui
# zW9zI/6sVgWQ8DIhFonGcIj5BZd9o8dD3QLoOz3tsUGj7T++25VIxO4es/K8DCuZ
# 0MZdEkKB4YNugnM/JksUkK5ZZgrEjb7SzgaurYRvSISbT0C58Uzyr5j79s5AXVz2
# qPEvr+yJIvJrGGWxwXOt1/HYzx4KdFxCuGh+t9V3CidWfA9ipD8yFGCV/QcEogkC
# AwEAAaOCA3owggN2MA4GA1UdDwEB/wQEAwIBhjA7BgNVHSUENDAyBggrBgEFBQcD
# AQYIKwYBBQUHAwIGCCsGAQUFBwMDBggrBgEFBQcDBAYIKwYBBQUHAwgwggHSBgNV
# HSAEggHJMIIBxTCCAbQGCmCGSAGG/WwAAQQwggGkMDoGCCsGAQUFBwIBFi5odHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRvcnkuaHRtMIIBZAYI
# KwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAg
# AEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAg
# AGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBl
# AHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBu
# AGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAg
# AGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAg
# AGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIABy
# AGUAZgBlAHIAZQBuAGMAZQAuMAsGCWCGSAGG/WwDFTASBgNVHRMBAf8ECDAGAQH/
# AgEAMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGBBgNVHR8EejB4MDqgOKA2
# hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290
# Q0EuY3JsMDqgOKA2hjRodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRB
# c3N1cmVkSURSb290Q0EuY3JsMB0GA1UdDgQWBBQVABIrE5iymQftHt+ivlcNK2cC
# zTAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzANBgkqhkiG9w0BAQUF
# AAOCAQEARlA+ybcoJKc4HbZbKa9Sz1LpMUerVlx71Q0LQbPv7HUfdDjyslxhopyV
# w1Dkgrkj0bo6hnKtOHisdV0XFzRyR4WUVtHruzaEd8wkpfMEGVWp5+Pnq2LN+4st
# kMLA0rWUvV5PsQXSDj0aqRRbpoYxYqioM+SbOafE9c4deHaUJXPkKqvPnHZL7V/C
# SxbkS3BMAIke/MV5vEwSV/5f4R68Al2o/vsHOE8Nxl2RuQ9nRc3Wg+3nkg2NsWmM
# T/tZ4CMP0qquAHzunEIOz5HXJ7cW7g/DvXwKoO4sCFWFIrjrGBpN/CohrUkxg0eV
# d3HcsRtLSxwQnHcUwZ1PL1qVCCkQJjGCBEwwggRIAgEBMIGGMHIxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNp
# Z25pbmcgQ0ECEAffyL/8OmT0J383waQCG3wwDQYJYIZIAWUDBAIBBQCggYQwGAYK
# KwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIB
# BDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg
# UINopO3lJgmutbCe4Fm602QNUitc62fiDlcHfqzXrbEwDQYJKoZIhvcNAQEBBQAE
# ggEAIsOjnyn7YEDiKHVWAJfKQ6Z1x0ePfP8VVSwsRK+tyxtYEmqkb9jy2yqrLgm6
# OYn0ziuv5HcifXxKMLQHTDE+COlbc6zSZ0W1/hMv2njesYx7FTG1+4+AEfK1jE7V
# PBX6RiyPDqjo5HeIfqm87I9bjI06aiMuB/JEq71Db3Iq3Iw8hJonFK0X9KLpPbFL
# SeRM1INKOsA8LHE1kPJMpI4z0WShACc2/mj/h1B/PItkai2PT5BSIN4PnJWwRDbd
# i9TcMYnzox7Uq8HNR64BtPB7wty5qPwaKA3dTnnGuYlxuiTWsnqOMVtLOCQ++Qab
# 3Un0xdVvzVu+o2glJoHByAf+q6GCAg8wggILBgkqhkiG9w0BCQYxggH8MIIB+AIB
# ATB2MGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNV
# BAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3VyZWQg
# SUQgQ0EtMQIQAwGaAjr/WLFr1tXq5hfwZjAJBgUrDgMCGgUAoF0wGAYJKoZIhvcN
# AQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTgxMDAyMTAyMjUxWjAj
# BgkqhkiG9w0BCQQxFgQUiWvrgc4/JxBV3RgaBDEoGyM0okowDQYJKoZIhvcNAQEB
# BQAEggEAYlIkPgDs3UVlORxiyWseOFkuDigdg9C19uARoTag33ycGy1AXQ4HEEKd
# ml8L+BpyBXJ/R9t1v0v2CQ5fTYfOo6L9mEIwE+BsyQkSbxuoDKzvLuHKcOYI6quN
# fwuGhMtZYidUrneY8ESFw5UcmJImMsdPaKpLeLkDbq3vru/iwCqp58t1ANisLhAm
# REfDpmRBAO2Zv8YSkWPyXryJ9LeC4BcFXlzp3Z1FV04MBlNGfIuIORoZrNcAkFne
# 1rKppqHZL63ZnMLQISnpSpl4oybSO5dvhyxTpizK4Sx536bSaeaQunmA55hosQrK
# D2fOhG0fDxqK84vUQTT1gTWMzyiw/A==
# SIG # End signature block
